#!/usr/bin/perl
use strict;

print STDERR "Time for install routine\n";
